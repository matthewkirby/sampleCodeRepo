from distutils.core import setup

setup(name='samplePKG',
      version='1.0',
      description='Performs basic math functions',
      author='Matthew Kirby',
      author_email='matthewkirby@email.arizona.edu',
      packages=['samplePKG'],
     )
