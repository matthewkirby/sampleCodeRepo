def myAdd(a, b):
    return a+b

def mySub(a, b):
    return a-b

def myMul(a, b):
    return float(a*b)

def myDiv(a, b):
    return float(a)/float(b)
